# Changelog por Entrega/Sprint

**Versión / Sprint:**  
**Fecha:**  

## Cambios
- Nueva funcionalidad: …  
- Mejoras: …  
- Fixes: …  

**Migraciones/Notas técnicas:**  
**Impacto en usuario:**  
**Riesgos conocidos y mitigación:**
