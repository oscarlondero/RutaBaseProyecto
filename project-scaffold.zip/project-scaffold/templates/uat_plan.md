# Plan de UAT (aceptación de usuario)

**Alcance UAT:**  
**Ambiente/Accesos:**  

## Casos de prueba (alto nivel)
| Caso | Paso clave | Resultado esperado | Estado | Observaciones |
|---|---|---|---|---|

**Criterios de aceptación globales:**  
**Ventana UAT y responsables:**  
**Acta de conformidad / pendientes:**
