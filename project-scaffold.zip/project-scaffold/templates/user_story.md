# Historia de Usuario

**ID:**  
**Título:**  
**Historia (Como/Quiero/Para):**  
**Criterios de aceptación (GWT):**  
- Dado … Cuando … Entonces …  
- Dado … Cuando … Entonces …  
**Prioridad (MoSCoW):**  
**Dependencias:**  
**Notas de UX (wireframe/link):**  
**DoR listo?** Sí / No (qué falta)  
**Estimación:**
