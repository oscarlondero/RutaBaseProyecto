# Requerimientos + Priorización MoSCoW

**Épica:**  
**Historias:**  

| ID | Descripción breve | Must/Should/Could/Won’t | Criterios de aceptación (link) |
|---|---|---|---|
