# Retro del Proyecto

**¿Qué salió bien?**  
**¿Qué mejorar?**  
**Acciones concretas (dueño/fecha):**  
**Impedimentos sistémicos a escalar:**
