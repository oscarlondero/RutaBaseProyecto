# Project Brief (1 página)

**Proyecto:**  
**Sponsor / Demandante:**  
**Stakeholders:**  
**Problema / Oportunidad (1–2 frases):**  
**Objetivo SMART:**  
**Alcance (incluye / excluye):**  
**Métricas de éxito (KPI):**  
**Hitos y fechas (demo, UAT, deploy):**  
**Riesgos top-3 + mitigación:**  
**Canales y frecuencia de comunicación:**  
**Ambiente técnico (alto nivel):**  
**Aprobación (firma/ok):**
