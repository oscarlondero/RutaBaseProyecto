# Paquete de Entrega (deploy)

**URL Producción:**  
**Usuario demo:**  

## Manual de usuario
(link/pdf)

## Manual técnico corto
- Infra/ENV
- Jobs/Crons
- Backup/Restore
- Monitoreo

**Plan de soporte (SLA, canales):**  
**Licencia / Propiedad / Confidencialidad (si aplica):**
