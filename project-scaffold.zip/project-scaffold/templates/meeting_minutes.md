# Acta de Reunión / Demo

**Fecha:**  
**Participantes:**  
**Objetivo de la sesión:**  
**Demo/Temas tratados:**  
**Decisiones:**  
**Observaciones / Cambios solicitados:**  
**Acciones (responsable/fecha):**  
**Próxima fecha/hito:**
